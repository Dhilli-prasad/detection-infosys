# Inference using your Roboflow-hosted model (cloud API)
#
# Steps:
#   pip install roboflow
#   python infer_roboflow.py
#
# WARNING: Never share your full API key publicly.

from roboflow import Roboflow

# TODO: replace with your real values
API_KEY = "YOUR_API_KEY_HERE"          # e.g. rf_xxxxxxxxxxxxxxxxxxxxxxxxx
PROJECT_ID = "YOUR_PROJECT_ID_HERE"    # e.g. video-surveilance-object-detecti
VERSION_NUMBER = 7                     # e.g. 7
IMAGE_PATH = "test_image.jpg"          # path to an image file

def main():
    rf = Roboflow(api_key=API_KEY)
    project = rf.workspace().project(PROJECT_ID)
    model = project.version(VERSION_NUMBER).model

    # Get prediction as JSON
    prediction = model.predict(IMAGE_PATH).json()
    print(prediction)

    # Also save image with bounding boxes drawn
    model.predict(IMAGE_PATH).save("prediction_result.jpg")
    print("Saved: prediction_result.jpg")

if __name__ == "__main__":
    main()
