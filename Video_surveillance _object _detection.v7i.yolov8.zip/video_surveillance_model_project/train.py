# YOLOv8 training script for your dataset
#
# Steps to use:
# 1. Install dependencies:
#       pip install ultralytics
# 2. Run:
#       python train.py
#
# This will train a YOLOv8 model on the data.yaml in this folder.

from ultralytics import YOLO

def main():
    # Choose a base model: 'yolov8n.pt', 'yolov8s.pt', etc.
    model = YOLO("yolov8n.pt")

    # Train using the local data.yaml (automatically uses train/val/test folders)
    model.train(
        data="data.yaml",
        epochs=50,
        imgsz=640,
        project="runs",
        name="video_surveillance_v7",
        exist_ok=True
    )

    # After training, best weights will be saved under runs/detect/video_surveillance_v7/weights/best.pt

if __name__ == "__main__":
    main()
