# video surveilance object detecti > 2025-12-05 11:06pm
https://universe.roboflow.com/my-ai-projects-5o2ee/video-surveilance-object-detecti

Provided by a Roboflow user
License: CC BY 4.0

